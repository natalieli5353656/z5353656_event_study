"""
toolkit_config.py
Project configuration file
**Do not submit**

"""


import os

PRJDIR = r"C:\Users\DELL\PycharmProjects\toolkit"
DATADIR = os.path.join(PRJDIR, 'data')
